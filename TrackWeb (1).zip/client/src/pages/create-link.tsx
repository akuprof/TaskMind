import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertTrackingLinkSchema } from "@shared/schema";
import { Link, Check, Copy } from "lucide-react";

const formSchema = insertTrackingLinkSchema.extend({
  originalUrl: z.string().url("Please enter a valid URL"),
});

type FormData = z.infer<typeof formSchema>;

export default function CreateLink() {
  const [generatedLink, setGeneratedLink] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      originalUrl: "",
      campaignName: "",
      collectLocation: true,
      collectDevice: true,
      requestCamera: false,
      isActive: true,
    },
  });

  const createLink = useMutation({
    mutationFn: (data: FormData) => apiRequest('POST', '/api/links', data),
    onSuccess: async (response) => {
      const link = await response.json();
      const trackingUrl = `${window.location.origin}/t/${link.shortCode}`;
      setGeneratedLink(trackingUrl);
      queryClient.invalidateQueries({ queryKey: ['/api/links'] });
      toast({
        title: "Success!",
        description: "Tracking link created successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create tracking link",
        variant: "destructive",
      });
    },
  });

  const copyToClipboard = async () => {
    if (!generatedLink) return;
    
    try {
      await navigator.clipboard.writeText(generatedLink);
      toast({
        title: "Copied!",
        description: "Link copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy link",
        variant: "destructive",
      });
    }
  };

  const onSubmit = (data: FormData) => {
    createLink.mutate(data);
  };

  const resetForm = () => {
    form.reset();
    setGeneratedLink(null);
  };

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Create Tracking Link</h1>
        <p className="text-gray-600">Generate a new tracking link to monitor clicks and capture visitor data</p>
      </div>

      <div className="max-w-2xl">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Link className="h-5 w-5" />
              <span>Link Configuration</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div>
                <Label htmlFor="originalUrl">
                  Original URL <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="originalUrl"
                  placeholder="https://example.com/your-page"
                  {...form.register("originalUrl")}
                  className="mt-1"
                />
                {form.formState.errors.originalUrl && (
                  <p className="text-sm text-red-500 mt-1">
                    {form.formState.errors.originalUrl.message}
                  </p>
                )}
                <p className="text-xs text-gray-500 mt-1">Enter the URL you want to track</p>
              </div>

              <div>
                <Label htmlFor="campaignName">Campaign Name</Label>
                <Input
                  id="campaignName"
                  placeholder="Social Media Campaign"
                  {...form.register("campaignName")}
                  className="mt-1"
                />
                <p className="text-xs text-gray-500 mt-1">Optional: Give your campaign a memorable name</p>
              </div>

              <div>
                <Label className="text-base font-medium">Data Collection Options</Label>
                <div className="space-y-3 mt-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="collectLocation"
                      checked={form.watch("collectLocation") || false}
                      onCheckedChange={(checked) => 
                        form.setValue("collectLocation", checked as boolean)
                      }
                    />
                    <Label htmlFor="collectLocation" className="text-sm">
                      Collect visitor location data
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="collectDevice"
                      checked={form.watch("collectDevice") || false}
                      onCheckedChange={(checked) => 
                        form.setValue("collectDevice", checked as boolean)
                      }
                    />
                    <Label htmlFor="collectDevice" className="text-sm">
                      Collect device and browser information
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="requestCamera"
                      checked={form.watch("requestCamera") || false}
                      onCheckedChange={(checked) => 
                        form.setValue("requestCamera", checked as boolean)
                      }
                    />
                    <Label htmlFor="requestCamera" className="text-sm">
                      Request camera access (optional)
                    </Label>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-3">
                <Button type="button" variant="outline" onClick={resetForm}>
                  Reset
                </Button>
                <Button type="submit" disabled={createLink.isPending}>
                  {createLink.isPending ? (
                    "Creating..."
                  ) : (
                    <>
                      <Link className="mr-2 h-4 w-4" />
                      Generate Link
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Success State */}
        {generatedLink && (
          <Card className="mt-6 border-green-200 bg-green-50">
            <CardContent className="pt-6">
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <Check className="h-4 w-4 text-green-600" />
                </div>
                <div className="flex-1">
                  <h3 className="text-sm font-medium text-green-900">
                    Tracking Link Created Successfully!
                  </h3>
                  <div className="mt-3">
                    <Label className="text-xs font-medium text-green-700">
                      Your tracking link:
                    </Label>
                    <div className="flex items-center space-x-2 mt-1">
                      <Input
                        value={generatedLink}
                        readOnly
                        className="flex-1 bg-white border-green-300 text-sm"
                      />
                      <Button 
                        size="sm" 
                        onClick={copyToClipboard}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
