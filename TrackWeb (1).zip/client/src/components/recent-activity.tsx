import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MousePointer, Plus, Camera } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface ActivityItem {
  type: 'click' | 'link_created';
  timestamp: string;
  linkName: string;
  location?: any;
  deviceInfo?: any;
  cameraGranted?: boolean;
}

export function RecentActivity() {
  const { data: activity = [], isLoading } = useQuery<ActivityItem[]>({
    queryKey: ['/api/activity'],
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg animate-pulse">
                <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-1"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Recent Activity</CardTitle>
          <Button variant="ghost" size="sm" className="text-primary hover:text-primary">
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {activity.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <MousePointer className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p>No recent activity</p>
          </div>
        ) : (
          <div className="space-y-4">
            {activity.map((item, index) => (
              <div key={index} className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  item.type === 'click' 
                    ? 'bg-green-100' 
                    : 'bg-blue-100'
                }`}>
                  {item.type === 'click' ? (
                    <MousePointer className={`h-4 w-4 ${
                      item.type === 'click' ? 'text-green-600' : 'text-blue-600'
                    }`} />
                  ) : (
                    <Plus className="h-4 w-4 text-blue-600" />
                  )}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">
                    {item.type === 'click' 
                      ? `Link clicked: ${item.linkName}`
                      : `New link created: ${item.linkName}`
                    }
                  </p>
                  <p className="text-xs text-gray-500">
                    {formatDistanceToNow(new Date(item.timestamp), { addSuffix: true })}
                    {item.location && ` • ${item.location.country || 'Unknown location'}`}
                  </p>
                </div>
                {item.cameraGranted && (
                  <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center">
                    <Camera className="h-3 w-3 text-purple-600" />
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
