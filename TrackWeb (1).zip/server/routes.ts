import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertTrackingLinkSchema, insertTrackingClickSchema } from "@shared/schema";
import { z } from "zod";
import fs from "fs";
import path from "path";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  const connectedClients = new Set<WebSocket>();

  wss.on('connection', (ws) => {
    connectedClients.add(ws);
    
    ws.on('close', () => {
      connectedClients.delete(ws);
    });
  });

  function broadcastUpdate(type: string, data: any) {
    const message = JSON.stringify({ type, data });
    connectedClients.forEach(ws => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(message);
      }
    });
  }

  // API Routes
  
  // Get all tracking links
  app.get('/api/links', async (req, res) => {
    try {
      const links = await storage.getAllTrackingLinks();
      res.json(links);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch links' });
    }
  });

  // Create a new tracking link
  app.post('/api/links', async (req, res) => {
    try {
      const validatedData = insertTrackingLinkSchema.parse(req.body);
      const link = await storage.createTrackingLink(validatedData);
      
      broadcastUpdate('linkCreated', link);
      res.json(link);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: 'Invalid data', errors: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to create link' });
      }
    }
  });

  // Update a tracking link
  app.patch('/api/links/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const updatedLink = await storage.updateTrackingLink(id, updates);
      if (!updatedLink) {
        return res.status(404).json({ message: 'Link not found' });
      }
      
      broadcastUpdate('linkUpdated', updatedLink);
      res.json(updatedLink);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update link' });
    }
  });

  // Delete a tracking link
  app.delete('/api/links/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteTrackingLink(id);
      
      if (!deleted) {
        return res.status(404).json({ message: 'Link not found' });
      }
      
      broadcastUpdate('linkDeleted', { id });
      res.json({ message: 'Link deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete link' });
    }
  });

  // Get tracking clicks for a specific link
  app.get('/api/links/:id/clicks', async (req, res) => {
    try {
      const { id } = req.params;
      const clicks = await storage.getTrackingClicksByLinkId(id);
      res.json(clicks);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch clicks' });
    }
  });

  // Get all tracking clicks for analytics
  app.get('/api/clicks', async (req, res) => {
    try {
      const { startDate, endDate } = req.query;
      
      let clicks;
      if (startDate && endDate) {
        clicks = await storage.getTrackingClicksInDateRange(
          new Date(startDate as string),
          new Date(endDate as string)
        );
      } else {
        clicks = await storage.getAllTrackingClicks();
      }
      
      res.json(clicks);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch clicks' });
    }
  });

  // Get dashboard stats
  app.get('/api/stats', async (req, res) => {
    try {
      const links = await storage.getAllTrackingLinks();
      const clicks = await storage.getAllTrackingClicks();
      
      const totalLinks = links.length;
      const totalClicks = clicks.length;
      const activeLinks = links.filter(link => link.isActive).length;
      const dataCaptured = clicks.filter(click => click.location || click.deviceInfo).length;
      
      const now = new Date();
      const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
      const lastWeek = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      
      const linksLastMonth = links.filter(link => link.createdAt! > lastMonth).length;
      const clicksLastMonth = clicks.filter(click => click.timestamp! > lastMonth).length;
      const dataLastWeek = clicks.filter(click => 
        click.timestamp! > lastWeek && (click.location || click.deviceInfo)
      ).length;
      
      const stats = {
        totalLinks,
        totalClicks,
        activeLinks,
        dataCaptured,
        growth: {
          links: linksLastMonth > 0 ? Math.round((linksLastMonth / totalLinks) * 100) : 0,
          clicks: clicksLastMonth > 0 ? Math.round((clicksLastMonth / totalClicks) * 100) : 0,
          data: dataLastWeek > 0 ? Math.round((dataLastWeek / dataCaptured) * 100) : 0,
        }
      };
      
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch stats' });
    }
  });

  // Get recent activity
  app.get('/api/activity', async (req, res) => {
    try {
      const clicks = await storage.getAllTrackingClicks();
      const links = await storage.getAllTrackingLinks();
      
      const recentClicks = clicks.slice(0, 10).map(click => {
        const link = links.find(l => l.id === click.linkId);
        return {
          type: 'click',
          timestamp: click.timestamp,
          linkName: link?.campaignName || 'Unnamed Campaign',
          location: click.location,
          deviceInfo: click.deviceInfo,
          cameraGranted: click.cameraGranted,
        };
      });
      
      const recentLinks = links.slice(0, 5).map(link => ({
        type: 'link_created',
        timestamp: link.createdAt,
        linkName: link.campaignName || 'Unnamed Campaign',
      }));
      
      const allActivity = [...recentClicks, ...recentLinks]
        .sort((a, b) => new Date(b.timestamp!).getTime() - new Date(a.timestamp!).getTime())
        .slice(0, 10);
      
      res.json(allActivity);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch activity' });
    }
  });

  // Tracking redirect route - serves the tracking page
  app.get('/t/:shortCode', async (req, res) => {
    try {
      const { shortCode } = req.params;
      const link = await storage.getTrackingLinkByShortCode(shortCode);
      
      if (!link || !link.isActive) {
        return res.status(404).send('Link not found or inactive');
      }

      // Read the tracking HTML template
      const trackingHtmlPath = path.join(import.meta.dirname, 'tracking.html');
      let html = fs.readFileSync(trackingHtmlPath, 'utf-8');
      
      // Replace placeholders
      html = html.replace('{{ORIGINAL_URL}}', link.originalUrl);
      html = html.replace('{{LINK_ID}}', link.id);
      html = html.replace('{{COLLECT_LOCATION}}', link.collectLocation ? 'true' : 'false');
      html = html.replace('{{COLLECT_DEVICE}}', link.collectDevice ? 'true' : 'false');
      html = html.replace('{{REQUEST_CAMERA}}', link.requestCamera ? 'true' : 'false');
      
      res.send(html);
    } catch (error) {
      res.status(500).send('Server error');
    }
  });

  // Record tracking data from the tracking page
  app.post('/api/track', async (req, res) => {
    try {
      const trackingData = {
        linkId: req.body.linkId,
        ipAddress: req.ip || req.connection.remoteAddress,
        userAgent: req.get('User-Agent'),
        location: req.body.location,
        deviceInfo: req.body.deviceInfo,
        cameraGranted: req.body.cameraGranted,
      };

      const validatedData = insertTrackingClickSchema.parse(trackingData);
      const click = await storage.createTrackingClick(validatedData);
      
      broadcastUpdate('clickRecorded', click);
      res.json({ success: true });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: 'Invalid tracking data', errors: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to record tracking data' });
      }
    }
  });

  return httpServer;
}
