import { LinksTable } from "@/components/links-table";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useLocation } from "wouter";

export default function MyLinks() {
  const [, setLocation] = useLocation();

  return (
    <div className="p-6">
      <div className="mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">My Links</h1>
            <p className="text-gray-600">Manage and monitor all your tracking links</p>
          </div>
          <Button 
            className="mt-4 sm:mt-0"
            onClick={() => setLocation('/create')}
          >
            <Plus className="mr-2 h-4 w-4" />
            Create New Link
          </Button>
        </div>
      </div>

      <LinksTable />
    </div>
  );
}
