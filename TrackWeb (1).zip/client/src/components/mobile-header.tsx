import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, Link as LinkIcon, User } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

const navigation = [
  { name: 'Dashboard', href: '/' },
  { name: 'Create Link', href: '/create' },
  { name: 'My Links', href: '/links' },
  { name: 'Analytics', href: '/analytics' },
  { name: 'Help & FAQ', href: '/help' },
];

export function MobileHeader() {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);

  return (
    <header className="bg-white border-b border-gray-200 lg:hidden">
      <div className="flex items-center justify-between px-4 py-3">
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-64 p-0">
            <div className="flex items-center justify-between h-16 px-4 border-b border-gray-200">
              <div className="flex items-center space-x-2">
                <div className="w-6 h-6 bg-primary rounded flex items-center justify-center">
                  <LinkIcon className="h-3 w-3 text-primary-foreground" />
                </div>
                <span className="text-lg font-bold text-gray-900">TrackWithAK</span>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setOpen(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            
            <nav className="flex-1 px-4 py-6 space-y-2">
              {navigation.map((item) => {
                const isActive = location === item.href;
                return (
                  <Link key={item.name} href={item.href}>
                    <div 
                      className={cn(
                        "flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors cursor-pointer",
                        isActive
                          ? "text-primary bg-primary/10"
                          : "text-gray-700 hover:bg-gray-100"
                      )}
                      onClick={() => setOpen(false)}
                    >
                      {item.name}
                    </div>
                  </Link>
                );
              })}
            </nav>
          </SheetContent>
        </Sheet>
        
        <div className="flex items-center space-x-2">
          <div className="w-6 h-6 bg-primary rounded flex items-center justify-center">
            <LinkIcon className="h-3 w-3 text-primary-foreground" />
          </div>
          <span className="text-lg font-bold text-gray-900">TrackWithAK</span>
        </div>
        
        <Button variant="ghost" size="icon">
          <User className="h-5 w-5" />
        </Button>
      </div>
    </header>
  );
}
