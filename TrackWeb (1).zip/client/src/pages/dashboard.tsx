import { useQuery } from "@tanstack/react-query";
import { StatsCard } from "@/components/stats-card";
import { RecentActivity } from "@/components/recent-activity";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link, MousePointer, BarChart3, Database, Plus, Download } from "lucide-react";
import { useLocation } from "wouter";
import { useWebSocket } from "@/hooks/use-websocket";
import { useEffect } from "react";

interface DashboardStats {
  totalLinks: number;
  totalClicks: number;
  activeLinks: number;
  dataCaptured: number;
  growth: {
    links: number;
    clicks: number;
    data: number;
  };
}

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const { subscribe, unsubscribe } = useWebSocket();

  const { data: stats, refetch } = useQuery<DashboardStats>({
    queryKey: ['/api/stats'],
  });

  useEffect(() => {
    // Subscribe to real-time updates
    subscribe('linkCreated', () => refetch());
    subscribe('clickRecorded', () => refetch());
    subscribe('linkUpdated', () => refetch());
    subscribe('linkDeleted', () => refetch());

    return () => {
      unsubscribe('linkCreated');
      unsubscribe('clickRecorded');
      unsubscribe('linkUpdated');
      unsubscribe('linkDeleted');
    };
  }, [subscribe, unsubscribe, refetch]);

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Dashboard</h1>
        <p className="text-gray-600">Overview of your tracking campaigns and link performance</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatsCard
          title="Total Links"
          value={stats?.totalLinks || 0}
          growth={stats?.growth.links?.toString()}
          growthLabel="from last month"
          icon={Link}
          iconColor="bg-blue-100 text-blue-600"
        />
        <StatsCard
          title="Total Clicks"
          value={stats?.totalClicks || 0}
          growth={stats?.growth.clicks?.toString()}
          growthLabel="from last month"
          icon={MousePointer}
          iconColor="bg-green-100 text-green-600"
        />
        <StatsCard
          title="Active Campaigns"
          value={stats?.activeLinks || 0}
          icon={BarChart3}
          iconColor="bg-yellow-100 text-yellow-600"
        />
        <StatsCard
          title="Data Captured"
          value={stats?.dataCaptured || 0}
          growth={stats?.growth.data?.toString()}
          growthLabel="from last week"
          icon={Database}
          iconColor="bg-purple-100 text-purple-600"
        />
      </div>

      {/* Quick Actions */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button 
              className="flex items-center justify-center" 
              onClick={() => setLocation('/create')}
            >
              <Plus className="mr-2 h-4 w-4" />
              Create New Link
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center justify-center"
              onClick={() => setLocation('/analytics')}
            >
              <BarChart3 className="mr-2 h-4 w-4" />
              View Analytics
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center justify-center"
            >
              <Download className="mr-2 h-4 w-4" />
              Export Data
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <RecentActivity />
    </div>
  );
}
