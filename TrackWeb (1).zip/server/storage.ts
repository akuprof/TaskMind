import { users, trackingLinks, trackingClicks, type User, type InsertUser, type TrackingLink, type InsertTrackingLink, type TrackingClick, type InsertTrackingClick } from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createTrackingLink(link: InsertTrackingLink): Promise<TrackingLink>;
  getTrackingLinkByShortCode(shortCode: string): Promise<TrackingLink | undefined>;
  getTrackingLinkById(id: string): Promise<TrackingLink | undefined>;
  getAllTrackingLinks(): Promise<TrackingLink[]>;
  updateTrackingLink(id: string, updates: Partial<TrackingLink>): Promise<TrackingLink | undefined>;
  deleteTrackingLink(id: string): Promise<boolean>;
  
  createTrackingClick(click: InsertTrackingClick): Promise<TrackingClick>;
  getTrackingClicksByLinkId(linkId: string): Promise<TrackingClick[]>;
  getAllTrackingClicks(): Promise<TrackingClick[]>;
  getTrackingClicksInDateRange(startDate: Date, endDate: Date): Promise<TrackingClick[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async createTrackingLink(insertLink: InsertTrackingLink): Promise<TrackingLink> {
    const shortCode = this.generateShortCode();
    
    const [link] = await db
      .insert(trackingLinks)
      .values({
        ...insertLink,
        shortCode,
      })
      .returning();
    
    return link;
  }

  async getTrackingLinkByShortCode(shortCode: string): Promise<TrackingLink | undefined> {
    const [link] = await db.select().from(trackingLinks).where(eq(trackingLinks.shortCode, shortCode));
    return link || undefined;
  }

  async getTrackingLinkById(id: string): Promise<TrackingLink | undefined> {
    const [link] = await db.select().from(trackingLinks).where(eq(trackingLinks.id, id));
    return link || undefined;
  }

  async getAllTrackingLinks(): Promise<TrackingLink[]> {
    return await db.select().from(trackingLinks).orderBy(desc(trackingLinks.createdAt));
  }

  async updateTrackingLink(id: string, updates: Partial<TrackingLink>): Promise<TrackingLink | undefined> {
    const [updatedLink] = await db
      .update(trackingLinks)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(trackingLinks.id, id))
      .returning();
    
    return updatedLink || undefined;
  }

  async deleteTrackingLink(id: string): Promise<boolean> {
    // Delete associated clicks first
    await db.delete(trackingClicks).where(eq(trackingClicks.linkId, id));
    
    // Delete the link
    const result = await db.delete(trackingLinks).where(eq(trackingLinks.id, id));
    return result.rowCount > 0;
  }

  async createTrackingClick(insertClick: InsertTrackingClick): Promise<TrackingClick> {
    const [click] = await db
      .insert(trackingClicks)
      .values(insertClick)
      .returning();
    
    // Increment click count on the link
    const [currentLink] = await db.select({ clickCount: trackingLinks.clickCount }).from(trackingLinks).where(eq(trackingLinks.id, insertClick.linkId));
    const newCount = (currentLink?.clickCount || 0) + 1;
    
    await db
      .update(trackingLinks)
      .set({ clickCount: newCount })
      .where(eq(trackingLinks.id, insertClick.linkId));
    
    return click;
  }

  async getTrackingClicksByLinkId(linkId: string): Promise<TrackingClick[]> {
    return await db.select().from(trackingClicks)
      .where(eq(trackingClicks.linkId, linkId))
      .orderBy(desc(trackingClicks.timestamp));
  }

  async getAllTrackingClicks(): Promise<TrackingClick[]> {
    return await db.select().from(trackingClicks).orderBy(desc(trackingClicks.timestamp));
  }

  async getTrackingClicksInDateRange(startDate: Date, endDate: Date): Promise<TrackingClick[]> {
    return await db.select().from(trackingClicks)
      .where(
        and(
          gte(trackingClicks.timestamp, startDate),
          lte(trackingClicks.timestamp, endDate)
        )
      )
      .orderBy(desc(trackingClicks.timestamp));
  }

  private generateShortCode(): string {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < 8; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
}

export const storage = new DatabaseStorage();
