import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Rocket, 
  Book, 
  Headphones, 
  ChevronDown, 
  ChevronUp,
  Info,
  ArrowRight 
} from "lucide-react";

const faqs = [
  {
    question: "How do I create a tracking link?",
    answer: "To create a tracking link, navigate to the 'Create Link' section, enter your original URL, optionally add a campaign name, select your data collection preferences, and click 'Generate Link'. Your new tracking link will be created instantly."
  },
  {
    question: "What data can I collect from visitors?",
    answer: "You can collect visitor location (with permission), device information, browser details, IP addresses, and optionally request camera access. All data collection follows privacy best practices and applicable regulations."
  },
  {
    question: "Is the collected data secure?",
    answer: "Yes, all collected data is encrypted and stored securely. We follow industry-standard security practices and comply with data protection regulations. You have full control over your data and can export or delete it at any time."
  },
  {
    question: "Can I export my tracking data?",
    answer: "Absolutely! You can export your data from the Analytics section or the My Links table. Data is available in CSV format and includes all captured information for your campaigns."
  },
  {
    question: "How long are tracking links active?",
    answer: "Tracking links remain active indefinitely unless you manually pause or delete them. You can manage the status of your links from the 'My Links' section at any time."
  },
  {
    question: "Is there a limit to the number of links I can create?",
    answer: "There are no hard limits on the number of tracking links you can create. However, for optimal performance, we recommend organizing your campaigns effectively."
  },
  {
    question: "How accurate is the location data?",
    answer: "Location accuracy depends on the visitor's device and browser settings. GPS-enabled devices typically provide accuracy within 5-10 meters, while IP-based location can be accurate to the city level."
  },
  {
    question: "What happens if a visitor denies permissions?",
    answer: "If a visitor denies location or camera permissions, the tracking will still work for basic data (clicks, device info, IP address). The visitor will still be redirected to your original URL."
  }
];

interface FAQItemProps {
  question: string;
  answer: string;
  isOpen: boolean;
  onClick: () => void;
}

function FAQItem({ question, answer, isOpen, onClick }: FAQItemProps) {
  return (
    <div className="border border-gray-200 rounded-lg">
      <button
        onClick={onClick}
        className="w-full px-4 py-3 text-left flex items-center justify-between hover:bg-gray-50 rounded-lg"
      >
        <span className="font-medium text-gray-900">{question}</span>
        {isOpen ? (
          <ChevronUp className="h-4 w-4 text-gray-400" />
        ) : (
          <ChevronDown className="h-4 w-4 text-gray-400" />
        )}
      </button>
      {isOpen && (
        <div className="px-4 pb-3 text-gray-600 text-sm">
          {answer}
        </div>
      )}
    </div>
  );
}

export default function Help() {
  const [openFAQ, setOpenFAQ] = useState<number | null>(null);

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Help & FAQ</h1>
        <p className="text-gray-600">Everything you need to know about using TrackWithAK</p>
      </div>

      {/* Quick Help Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="pt-6">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <Rocket className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Quick Start</h3>
            <p className="text-gray-600 text-sm mb-4">
              Get up and running with your first tracking link in minutes
            </p>
            <Button variant="outline" size="sm" className="text-blue-600 border-blue-600 hover:bg-blue-50">
              Start Tutorial <ArrowRight className="ml-1 h-3 w-3" />
            </Button>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="pt-6">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
              <Book className="h-6 w-6 text-green-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Documentation</h3>
            <p className="text-gray-600 text-sm mb-4">
              Comprehensive guides and API documentation
            </p>
            <Button variant="outline" size="sm" className="text-green-600 border-green-600 hover:bg-green-50">
              View Docs <ArrowRight className="ml-1 h-3 w-3" />
            </Button>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="pt-6">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
              <Headphones className="h-6 w-6 text-purple-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Support</h3>
            <p className="text-gray-600 text-sm mb-4">
              Need help? Our support team is here for you
            </p>
            <Button variant="outline" size="sm" className="text-purple-600 border-purple-600 hover:bg-purple-50">
              Contact Us <ArrowRight className="ml-1 h-3 w-3" />
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* FAQ Section */}
      <Card>
        <CardHeader>
          <CardTitle>Frequently Asked Questions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <FAQItem
                key={index}
                question={faq.question}
                answer={faq.answer}
                isOpen={openFAQ === index}
                onClick={() => setOpenFAQ(openFAQ === index ? null : index)}
              />
            ))}
          </div>

          {/* Contact Support Card */}
          <Card className="mt-8 border-blue-200 bg-blue-50">
            <CardContent className="pt-4">
              <div className="flex items-start space-x-3">
                <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mt-0.5">
                  <Info className="h-3 w-3 text-blue-600" />
                </div>
                <div>
                  <h4 className="font-medium text-blue-900 mb-1">Still have questions?</h4>
                  <p className="text-blue-700 text-sm mb-3">
                    Can't find what you're looking for? Our support team is here to help.
                  </p>
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                    Contact Support
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );
}
