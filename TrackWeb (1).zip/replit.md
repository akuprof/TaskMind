# TrackWithAK - Link Tracking Dashboard

## Overview

TrackWithAK is a web-based link tracking application that allows users to create trackable URLs and collect visitor data including location, device information, and camera access. The application replaces a previous Telegram bot with a modern web dashboard built using React, Express.js, and PostgreSQL.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modern full-stack architecture with clear separation between frontend and backend concerns:

### Frontend Architecture
- **Framework**: React with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **UI Components**: Shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM (DatabaseStorage implementation)
- **Real-time Communication**: WebSocket server for live updates
- **API**: RESTful API endpoints for CRUD operations
- **Tracking**: Custom HTML template for visitor data collection

## Key Components

### Database Schema
The application uses three main entities:
1. **Users**: Basic user authentication (username/password)
2. **Tracking Links**: Core link tracking functionality with configuration options
3. **Tracking Clicks**: Click events with visitor data collection

### Frontend Pages
- **Dashboard**: Overview with statistics and recent activity
- **Create Link**: Form to generate new tracking links with customizable options
- **My Links**: Table view for managing existing links
- **Analytics**: Detailed analytics and data visualization
- **Help**: FAQ and documentation

### Data Collection Features
- Location tracking (with user permission)
- Device information (browser, OS, type)
- IP address logging
- Optional camera access requests
- Real-time click counting

## Data Flow

1. **Link Creation**: Users create tracking links through the web interface
2. **Link Sharing**: Generated short URLs redirect through the tracking system
3. **Data Collection**: Visitor interactions trigger data collection via custom HTML template
4. **Real-time Updates**: WebSocket connections provide live updates to the dashboard
5. **Analytics**: Collected data is processed and displayed in various analytics views

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection
- **drizzle-orm**: Type-safe database queries and migrations
- **@tanstack/react-query**: Server state management and caching
- **@radix-ui/**: Accessible UI component primitives
- **tailwindcss**: Utility-first CSS framework

### Development Tools
- **vite**: Fast build tool and development server
- **typescript**: Type safety and better developer experience
- **drizzle-kit**: Database migration and schema management

## Deployment Strategy

The application is designed for deployment on platforms supporting Node.js:

### Build Process
1. Frontend assets are built using Vite and output to `dist/public`
2. Backend is bundled using esbuild for Node.js runtime
3. Database migrations are managed through Drizzle Kit

### Environment Configuration
- `DATABASE_URL`: PostgreSQL connection string
- `NODE_ENV`: Environment setting (development/production)

### Hosting Considerations
- Static files served from the backend in production
- WebSocket support required for real-time features
- PostgreSQL database required (Neon Database recommended)

The architecture emphasizes developer experience with hot reloading, type safety, and modern tooling while maintaining production readiness with proper error handling and security considerations.