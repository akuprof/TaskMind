import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  BarChart3, 
  Link as LinkIcon, 
  Plus, 
  List, 
  HelpCircle 
} from "lucide-react";

const navigation = [
  { name: 'Dashboard', href: '/', icon: BarChart3 },
  { name: 'Create Link', href: '/create', icon: Plus },
  { name: 'My Links', href: '/links', icon: List },
  { name: 'Analytics', href: '/analytics', icon: BarChart3 },
  { name: 'Help & FAQ', href: '/help', icon: HelpCircle },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="hidden lg:flex lg:flex-col lg:w-64 lg:bg-white lg:border-r lg:border-gray-200">
      <div className="flex items-center justify-center h-16 px-4 border-b border-gray-200">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <LinkIcon className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className="text-xl font-bold text-gray-900">TrackWithAK</span>
        </div>
      </div>
      
      <nav className="flex-1 px-4 py-6 space-y-2">
        {navigation.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.name} href={item.href}>
              <div className={cn(
                "flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors cursor-pointer",
                isActive
                  ? "text-primary bg-primary/10"
                  : "text-gray-700 hover:bg-gray-100"
              )}>
                <item.icon className="mr-3 h-4 w-4" />
                {item.name}
              </div>
            </Link>
          );
        })}
      </nav>
      
      <div className="p-4 border-t border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
            <span className="text-xs font-medium text-gray-600">AK</span>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-900">AK User</p>
            <p className="text-xs text-gray-500">ak@example.com</p>
          </div>
        </div>
      </div>
    </div>
  );
}
